names = ['Jack', 'John', 'Jill', 'Jerry']
print (names)
names.append ('Aaron')
print (names)
names.remove ('Jack')
print (names)