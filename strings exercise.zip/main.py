#Strings exercise
#Create a variable and input (assign) a the string. For example, 'This is a String Example'
#Display the string (print)
#Display the 4th index value
#Display the length of the string
#Create a variable for age and input an age
#Display the string and the age
favorite_team = input('Enter your favorite sports team: \n')
print ('Your favorite team is', favorite_team)
print ('The 4th value is', favorite_team[4])
print ('The length of the string is', len(favorite_team), 'characters.')

new_age = input('Enter an age: \n')
print (favorite_team)
print (new_age)