family_ages = {
  'Sandy' : 31, 
  'Aaron' : 28 
}
print ('Aaron is',family_ages['Aaron'], 'years old.')